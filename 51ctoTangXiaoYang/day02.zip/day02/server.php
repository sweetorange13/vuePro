<?php
	//获取参数
	$name=$_POST['name'];
	$age=$_POST['age'];

	//响应数据
	echo '姓名：',$name,',年龄：',$age;
?>