<template>
	<div id="news">
		<h3>这是新闻</h3>
	</div>
</template>

<script>

</script>