import Vue from 'vue'

import {Button,Input,Radio,Select,Option,Table,TableColumn,Rate,Pagination,Carousel,CarouselItem} from 'element-ui'

Vue.use(Button);
Vue.use(Input);
Vue.use(Radio);
Vue.use(Select);
Vue.use(Option);
Vue.use(Table);
Vue.use(TableColumn);
Vue.use(Rate);
Vue.use(Pagination);
Vue.use(Carousel);
Vue.use(CarouselItem);